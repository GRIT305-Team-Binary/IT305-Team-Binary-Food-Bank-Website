<?php
	/* Sidebar for all Contribute pages
	 * Kent Food Bank 
	 * Jami Team Binary
	 * http://teambinary.greenrivertech.net/includes/contribute-side.php
	 */
?>
<div class="btn-group-vertical col-xs-12">
<a href="https://www.paypal.com/us/webapps/mpp/search-cause?charityId=120598&s=3" class="btn btn-warning"><span class="fa fa-paypal"></span> Donate</a>
<a href="volunteer.php" class="btn btn-default">Volunteer</a>
<a href="sponsor.php" class="btn btn-default">Become a Sponsor</a>
<a href="contribute.php" class="btn btn-default">Top Items We Need</a>
<a href="contribute.php#clothing" class="btn btn-default">Clothing Bank</a>
<a href="contribute.php#otherGift" class="btn btn-default">Other Ways to Give</a>
<a href="http://www.seattlefoundation.org/npos/Pages/KentFoodBankandEmergencyServices.aspx" class="btn btn-default" target="_blank">Seattle Foundation</a>
</div>