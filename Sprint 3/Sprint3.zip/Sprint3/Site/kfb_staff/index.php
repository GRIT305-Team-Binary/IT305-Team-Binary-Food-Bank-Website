<?php
	/* Kent Food Bank Staff
	 * Jami Team Binary
	 * http://teambinary.greenrivertech.net/kfb_staff/index.php
	 */
?>
	
		
<?php
	include('nav.php');
?>
			
<div class="container-fluid">	
		
	<div class="main">
		<div class="row">
			<div class="col-xs-12 col-sm-10 col-sm-offset-1 col-md-8 col-md-offset-2 ">
				<!-- Kent Food Bank Staff  -->
				<h1 class="text-center">This page is for the Kent Food Bank Staff</h1 >
				<p class="text-center">Update <a href="update_top_ten_items.php">Top Ten Items Needed</a></p>
				<p class="text-center"><a href="volunteers.php">Volunteer Applicants</a></p>
				<p class="text-center"><a href="sponsors.php">Breakfast Sponsors</a></p>
				
				<div id="embed-api-auth-container"></div>
				<div id="chart-container"></div>
				<div id="view-selector-container"></div>
				
			</div>
		</div>
	</div>
</div>
            
</body>
</html>
        
